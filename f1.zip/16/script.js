
function calcular() {
      const peso = parseFloat(document.getElementById("peso").value);
      const precoPorQuilo = 12.00;

      if (isNaN(peso)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha o campo de peso corretamente.";
        return;
      }

      if (peso < 0) {
        document.getElementById("resultado").innerHTML = "Peso não pode ser negativo.";
        return;
      }
const valorAPagar = peso * precoPorQuilo;
      document.getElementById("resultado").innerHTML = `Valor a pagar: R$ ${valorAPagar.toFixed(2)}`;
    }