
 function calcular() {
      const pequenas = parseInt(document.getElementById("pequenas").value);
      const medias = parseInt(document.getElementById("medias").value);
      const grandes = parseInt(document.getElementById("grandes").value);

      if (isNaN(pequenas) || isNaN(medias) || isNaN(grandes)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha todos os campos corretamente.";
        return;
      }
      if (pequenas < 0 || medias < 0 || grandes < 0) {
        document.getElementById("resultado").innerHTML = "Quantidade de camisetas não pode ser negativa.";
        return;
      }

      const precoPequena = 10;
      const precoMedia = 12;
      const precoGrande = 15;
      const total = pequenas * precoPequena + medias * precoMedia + grandes * precoGrande;
      document.getElementById("resultado").innerHTML = `Valor arrecadado: R$ ${total.toFixed(2)}`;
    }