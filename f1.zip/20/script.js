
function calcular() {
      const dias = parseInt(document.getElementById("dias").value);

      if (isNaN(dias) || dias < 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um número de dias válido.";
        return;
      }
const diasPorAno = 360;
      const diasPorMes = 30;

      const anos = Math.floor(dias / diasPorAno);
      const meses = Math.floor((dias % diasPorAno) / diasPorMes);
      const diasRestantes = dias % diasPorMes;

      document.getElementById("resultado").innerHTML = `${dias} dias equivalem a ${anos} anos, ${meses} meses e ${diasRestantes} dias.`;
    }