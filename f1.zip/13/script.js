

function calcular() {
      const paes = parseInt(document.getElementById("paes").value);
      const broas = parseInt(document.getElementById("broas").value);

      if (isNaN(paes) || isNaN(broas)) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos para pães e broas.";
        return;
      }

      if (paes < 0 || broas < 0) {
        document.getElementById("resultado").innerHTML = "Quantidade de pães e broas não pode ser negativa.";
        return;
      }
const precoPao = 0.12;
      const precoBroa = 1.50;
      const totalPaes = paes * precoPao;
      const totalBroas = broas * precoBroa;
      const totalVendas = totalPaes + totalBroas;
      const poupanca = totalVendas * 0.10;

      document.getElementById("resultado").innerHTML = `
        Total arrecadado com vendas: R$ ${totalVendas.toFixed(2)}<br>
        Total a guardar na poupança: R$ ${poupanca.toFixed(2)}
      `;
    }