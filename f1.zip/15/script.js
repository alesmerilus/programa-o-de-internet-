
function calcular() {
      const precoLitro = parseFloat(document.getElementById("precoLitro").value);
      const valorPagamento = parseFloat(document.getElementById("valorPagamento").value);

      if (isNaN(precoLitro) || isNaN(valorPagamento)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha todos os campos corretamente.";
        return;
      }

if (precoLitro <= 0 || valorPagamento < 0) {
        document.getElementById("resultado").innerHTML = "Preço do litro deve ser maior que zero e valor do pagamento não pode ser negativo.";
        return;
      }

      const litros = valorPagamento / precoLitro;
      document.getElementById("resultado").innerHTML = `Você conseguiu colocar ${litros.toFixed(2)} litros de gasolina no tanque.`;
    }