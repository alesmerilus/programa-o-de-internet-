
  function compararValores() {
        let valor1 = parseFloat(document.getElementById("valor1").value);
        let valor2 = parseFloat(document.getElementById("valor2").value);

        if (isNaN(valor1) || isNaN(valor2)) {
          document.getElementById("resultado").innerHTML = "Por favor, informe dois valores válidos.";
        } else if (valor1 > valor2) {
          document.getElementById("resultado").innerHTML = `O maior valor é: ${valor1}`;
        } else if (valor2 > valor1) {
          document.getElementById("resultado").innerHTML = `O maior valor é: ${valor2}`;
        } else {
          document.getElementById("resultado").innerHTML = "Os valores são iguais";
        }
      }