
 function calcular() {
      const nome = document.getElementById("nome").value.toUpperCase();
      const idade = parseInt(document.getElementById("idade").value);

      if (nome === "" || isNaN(idade)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha todos os campos corretamente.";
        return;
      }
if (idade < 0) {
        document.getElementById("resultado").innerHTML = "Idade não pode ser negativa.";
        return;
      }

      const diasPorAno = 365;
      const diasDeVida = idade * diasPorAno;
      document.getElementById("resultado").innerHTML = `${nome}, VOCÊ JÁ VIVEU ${diasDeVida} DIAS`;
    }