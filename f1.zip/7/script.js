
      function verificarImpar() {
        let valor = parseInt(document.getElementById("valor").value);

        if (isNaN(valor)) {
          document.getElementById("resultado").innerHTML = "Por favor, informe um valor válido.";
        } else if (valor % 2 !== 0) {
          document.getElementById("resultado").innerHTML = `O número ${valor} é ímpar.`;
        } else {
          document.getElementById("resultado").innerHTML = `O número ${valor} é par.`;
        }
      }
    