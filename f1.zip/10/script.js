
 function calcular() {
      const sabor1 = document.getElementById("sabor1").value;
      const sabor2 = document.getElementById("sabor2").value;
      const sabor3 = document.getElementById("sabor3").value;
      const sabor4 = document.getElementById("sabor4").value;
      const refrigerantes = parseInt(document.getElementById("refrigerantes").value);

      if (sabor1 === "" || sabor2 === "" || sabor3 === "" || sabor4 === "") {
        document.getElementById("resultado").innerHTML = "Por favor, preencha todos os sabores.";
        return;
      }
 if (isNaN(refrigerantes) || refrigerantes < 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um número de refrigerantes válido.";
        return;
      }

      const precoPizza = 12;
      const precoRefrigerante = 7;
      const totalPizzas = precoPizza * 4;
      const totalRefrigerantes = precoRefrigerante * refrigerantes;
      const total = totalPizzas + totalRefrigerantes;

      document.getElementById("resultado").innerHTML = `
        Você escolheu os seguintes sabores de pizza:<br>
        - ${sabor1}<br>
        - ${sabor2}<br>
        - ${sabor3}<br>
        - ${sabor4}<br>
        Você também escolheu ${refrigerantes} refrigerantes.<br>
        O total a pagar é: R$ ${total.toFixed(2)}
      `;
    }