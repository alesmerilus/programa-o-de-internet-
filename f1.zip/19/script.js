
function calcular() {
      const x1 = parseFloat(document.getElementById("x1").value);
      const y1 = parseFloat(document.getElementById("y1").value);
      const x2 = parseFloat(document.getElementById("x2").value);
      const y2 = parseFloat(document.getElementById("y2").value);

      if (isNaN(x1) || isNaN(y1) || isNaN(x2) || isNaN(y2)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha todos os campos corretamente.";
        return;
      }
const dx = x2 - x1;
      const dy = y2 - y1;
      const distancia = Math.sqrt(dx * dx + dy * dy);
      document.getElementById("resultado").innerHTML = `A distância entre os dois pontos é: ${distancia.toFixed(2)}`;
    }