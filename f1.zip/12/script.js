
function calcular() {
      const cavalos = parseInt(document.getElementById("cavalos").value);

      if (isNaN(cavalos) || cavalos < 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um número de cavalos válido.";
        return;
      }

 const ferradurasPorCavalo = 4;
      const totalFerraduras = cavalos * ferradurasPorCavalo;
      document.getElementById("resultado").innerHTML = `Serão necessárias ${totalFerraduras} ferraduras para equipar todos os cavalos.`;
    }