
function calcular() {
      const raio = parseFloat(document.getElementById("raio").value);
      const pi = 3.14;

      if (isNaN(raio) || raio <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um raio válido.";
        return;
      }

      const area = pi * (raio * raio);
      document.getElementById("resultado").innerHTML = `A área da pizza é: ${area.toFixed(2)}`;
    }