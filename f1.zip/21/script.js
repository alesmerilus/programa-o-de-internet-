
 function calcular() {
      const salario = parseFloat(document.getElementById("salario").value);

      if (isNaN(salario) || salario < 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um salário válido.";
        return;
      }

      const aumento = salario * 0.15;
      const salarioComAumento = salario + aumento;
      const imposto = salarioComAumento * 0.08;
      const salarioFinal = salarioComAumento - imposto;

 document.getElementById("resultado").innerHTML = `
        Salário inicial: R$ ${salario.toFixed(2)}<br>
        Salário com aumento: R$ ${salarioComAumento.toFixed(2)}<br>
        Salário final (após impostos): R$ ${salarioFinal.toFixed(2)}
      `;
    }