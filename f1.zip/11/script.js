
 function calcular() {
      const largura = parseFloat(document.getElementById("largura").value);
      const comprimento = parseFloat(document.getElementById("comprimento").value);

      if (isNaN(largura) || isNaN(comprimento)) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos para largura e comprimento.";
        return;
   }

      if (largura <= 0 || comprimento <= 0) {
        document.getElementById("resultado").innerHTML = "Largura e comprimento devem ser maiores que zero.";
        return;
      }

      const area = largura * comprimento;
      document.getElementById("resultado").innerHTML = `A área do terreno é: ${area.toFixed(2)} metros quadrados`;
    }