
let  inputnumero1 = document.querySelector("#inputnumero1"); 
let BTsomar = document.querySelector("#BTsoma") 
let resultado = document.querySelector("#resuldado")


function calcular(){

    let valor= Number(inputnumero1.value);
    let reajuste = valor+( valor*(1/100));
    resultado.textContent=reajuste;

}
BTsomar.onclick = function(){
    calcular();
} 