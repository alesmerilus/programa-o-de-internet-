let inputnomero1 = document.querySelector("#inputnomero1")
let inputnomero2 = document.querySelector("#inputnumero2")
let btsoma = document.querySelector("#btsoma")
let resultado = document.querySelector("#resultado")

function calcula(){
let ano= Number(inputnumero1.value);
let valor2= Number(inputnumero2.value);

}
//calcular a imposto
let taxa = 0;
if (ano <1990){
    taxa = 0.01;

}
else{
    taxa = 0.015;
}
//calcular o valor 
const imposto = valor*taxa;

document.getElementById('resultado').innerHTML = `O imposto a ser pago é R$ ${imposto.toFixed(2)}.`;

        


