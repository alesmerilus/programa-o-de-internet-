
function calcular() {
      const cotacao = parseFloat(document.getElementById("cotacao").value);
      if (isNaN(cotacao)) {
        document.getElementById("resultado").innerHTML = "Por favor, insira uma cotação válida.";
        return;
      }
 const aumentos = [1, 2, 5, 10];
      let resultado = "";

      aumentos.forEach(aumento => {
        const novoValor = cotacao + (cotacao * aumento / 100);
        resultado += `Com aumento de ${aumento}%: R$ ${novoValor.toFixed(2)}<br>`;
      });

      document.getElementById("resultado").innerHTML = `
        Cotação atual: R$ ${cotacao.toFixed(2)}<br>
        ${resultado}
      `;
    }