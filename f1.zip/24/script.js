
function calcular() {
      const valor = parseFloat(document.getElementById("valor").value);

      if (isNaN(valor) || valor <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um valor válido.";
        return;
      }

      const valorPorPessoa = valor / 3;
      const valorInteiro = Math.floor(valorPorPessoa);
      const valorCarlos = valorInteiro;
      const valorAndre = valorInteiro;
      const valorFelipe = valor - valorCarlos - valorAndre;
   document.getElementById("resultado").innerHTML = `
        Carlos deve pagar: R$ ${valorCarlos.toFixed(2)}<br>
        André deve pagar: R$ ${valorAndre.toFixed(2)}<br>
        Felipe deve pagar: R$ ${valorFelipe.toFixed(2)}
      `;
    }