
function calcular() {
      const numero = parseInt(document.getElementById("numero").value);

      if (isNaN(numero) || numero < 0 || numero > 999) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um número válido (até 3 dígitos).";
        return;
      }

      const centena = Math.floor(numero / 100);
      const dezena = Math.floor((numero % 100) / 10);
      const unidade = numero % 10;

      document.getElementById("resultado").innerHTML = `
        CENTENA = ${centena}<br>
        DEZENA = ${dezena}<br>
        UNIDADE = ${unidade}
      `;
    }