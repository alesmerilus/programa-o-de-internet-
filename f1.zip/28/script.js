function calcular() {
      const preco = parseFloat(document.getElementById("preco").value);
      const condicao = document.getElementById("condicao").value;

      if (isNaN(preco) || preco <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um preço válido.";
        return;
      }
let valorPagar;

      switch (condicao) {
        case "a":
          valorPagar = preco * 0.9;
          document.getElementById("resultado").innerHTML = `Valor a pagar: R$ ${valorPagar.toFixed(2)} (10% de desconto)`;
          break;
        case "b":
          valorPagar = preco * 0.85;
          document.getElementById("resultado").innerHTML = `Valor a pagar: R$ ${valorPagar.toFixed(2)} (15% de desconto)`;
          break;
        case "c":
          valorPagar = preco;
          document.getElementById("resultado").innerHTML = `Valor a pagar: R$ ${valorPagar.toFixed(2)} (2x sem juros)`;
          document.getElementById("resultado").innerHTML += `<br>Parcelas: 2x de R$ ${(valorPagar / 2).toFixed(2)}`;
          break;
        case "d":
          valorPagar = preco * 1.1;
          document.getElementById("resultado").innerHTML = `Valor a pagar: R$ ${valorPagar.toFixed(2)} (2x com juros de 10%)`;
          document.getElementById("resultado").innerHTML += `<br>Parcelas: 2x de R$ ${(valorPagar / 2).toFixed(2)}`;
          break;
      }
    }