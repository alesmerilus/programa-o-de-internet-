function calcular() {
      const pessoas = parseInt(document.getElementById("pessoas").value);
      if (isNaN(pessoas) || pessoas <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira um número de pessoas válido.";
        return;
      }
const ovosPorPessoa = 2;
      const queijoPorPessoa = 50;

      const totalOvos = pessoas * ovosPorPessoa;
      const totalQueijo = pessoas * queijoPorPessoa;

      document.getElementById("resultado").innerHTML = `
        Para ${pessoas} pessoas, você precisará de:<br>
        - ${totalOvos} ovos<br>
        - ${totalQueijo} gramas de queijo
      `;
    }