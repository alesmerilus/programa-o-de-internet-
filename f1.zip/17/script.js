
function calcular() {
      const dia = parseInt(document.getElementById("dia").value);
      const mes = parseInt(document.getElementById("mes").value);

      if (isNaN(dia) || isNaN(mes)) {
        document.getElementById("resultado").innerHTML = "Por favor, preencha todos os campos corretamente.";
        return;
      }
if (dia < 1 || dia > 30 || mes < 1 || mes > 12) {
        document.getElementById("resultado").innerHTML = "Dia deve estar entre 1 e 30 e mês deve estar entre 1 e 12.";
        return;
      }

      const diasPorMes = 30;
      const diasPassados = (mes - 1) * diasPorMes + dia;
      document.getElementById("resultado").innerHTML = `Passaram-se ${diasPassados} dias desde o início do ano.`;
    }