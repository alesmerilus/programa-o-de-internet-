
function verificar() {
      const x = parseFloat(document.getElementById("x").value);
      const y = parseFloat(document.getElementById("y").value);
      const z = parseFloat(document.getElementById("z").value);

      if (isNaN(x) || isNaN(y) || isNaN(z) || x <= 0 || y <= 0 || z <= 0) {
        document.getElementById("resultado").innerHTML = "Por favor, insira valores válidos.";
        return;
      }
      if (x < y + z && y < x + z && z < x + y) {
        if (x === y && y === z) {
          document.getElementById("resultado").innerHTML = "Triângulo equilátero.";
        } else if (x === y || y === z || x === z) {
          document.getElementById("resultado").innerHTML = "Triângulo isósceles.";
        } else {
          document.getElementById("resultado").innerHTML = "Triângulo escaleno.";
        }
      } else {
        document.getElementById("resultado").innerHTML = "Os valores não formam um triângulo.";
      }
    }